// Error dengan status HTTP, dilempar dari route lalu ditangkap oleh errorHandler.
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

// Membungkus handler async agar error otomatis diteruskan ke errorHandler.
const wrap = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);

function isMissing(value) {
  return value === undefined || value === null || value === '';
}

function parseId(value, field = 'ID') {
  const n = Number(value);
  if (isMissing(value) || typeof value === 'boolean' || !Number.isInteger(n) || n < 1) {
    throw new HttpError(400, `${field} harus berupa angka bulat positif`);
  }
  return n;
}

function reqId(value, field) {
  if (isMissing(value)) throw new HttpError(400, `Field ${field} wajib diisi`);
  return parseId(value, `Field ${field}`);
}

function reqStr(value, field, max = 255) {
  if (typeof value !== 'string' || !value.trim()) {
    throw new HttpError(400, `Field ${field} wajib diisi`);
  }
  const v = value.trim();
  if (v.length > max) throw new HttpError(400, `Field ${field} maksimal ${max} karakter`);
  return v;
}

function optStr(value, field, max = 2000) {
  if (isMissing(value)) return null;
  if (typeof value !== 'string') throw new HttpError(400, `Field ${field} harus berupa teks`);
  const v = value.trim();
  if (v.length > max) throw new HttpError(400, `Field ${field} maksimal ${max} karakter`);
  return v || null;
}

function reqNum(value, field, min = 0) {
  if (isMissing(value)) throw new HttpError(400, `Field ${field} wajib diisi`);
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min) {
    throw new HttpError(400, `Field ${field} harus berupa angka >= ${min}`);
  }
  return value;
}

function reqInt(value, field, min = 0) {
  if (isMissing(value)) throw new HttpError(400, `Field ${field} wajib diisi`);
  if (typeof value !== 'number' || !Number.isInteger(value) || value < min) {
    throw new HttpError(400, `Field ${field} harus berupa bilangan bulat >= ${min}`);
  }
  return value;
}

function reqEmail(value, field = 'email') {
  const v = reqStr(value, field, 150).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) throw new HttpError(400, 'Format email tidak valid');
  return v;
}

// Middleware 404 untuk URL yang tidak dikenal.
function notFound(req, res) {
  res.status(404).json({ error: 'Endpoint tidak ditemukan' });
}

// Middleware penanganan error terpusat. Selalu membalas JSON { "error": "..." }.
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  if (err instanceof HttpError) return res.status(err.status).json({ error: err.message });

  if (err.type === 'entity.parse.failed') {
    return res.status(400).json({ error: 'Format JSON tidak valid' });
  }

  switch (err.code) {
    case '23505': // unique_violation
      return res.status(409).json({ error: 'Data duplikat: nilai yang sama sudah ada' });
    case '23503': // foreign_key_violation
      if (/is not present in table/.test(err.detail || '')) {
        return res
          .status(400)
          .json({ error: 'Data referensi tidak ditemukan (periksa category_id, author_ids, atau user_id)' });
      }
      return res
        .status(409)
        .json({ error: 'Data tidak dapat dihapus karena masih dipakai oleh data lain' });
    case '23514': // check_violation
      return res.status(400).json({ error: 'Data melanggar aturan validasi database' });
    case '22P02': // invalid_text_representation
    case '22003': // numeric_value_out_of_range
      return res.status(400).json({ error: 'Format data tidak valid' });
    default:
      console.error(err);
      return res.status(500).json({ error: 'Terjadi kesalahan pada server' });
  }
}

module.exports = {
  HttpError,
  wrap,
  parseId,
  reqId,
  reqStr,
  optStr,
  reqNum,
  reqInt,
  reqEmail,
  notFound,
  errorHandler,
};
