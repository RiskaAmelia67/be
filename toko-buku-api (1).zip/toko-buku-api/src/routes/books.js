const router = require('express').Router();
const pool = require('../db');
const { withTransaction } = pool;
const { wrap, HttpError, parseId, reqId, reqStr, optStr, reqNum, reqInt } = require('../utils');

// Query dasar: buku + nama kategori + daftar penulis (JSON array).
const BOOK_SELECT = `
  SELECT b.id, b.title, b.description, b.price, b.stock, b.category_id,
         c.name AS category,
         COALESCE(
           json_agg(json_build_object('id', a.id, 'name', a.name) ORDER BY a.id)
             FILTER (WHERE a.id IS NOT NULL),
           '[]'
         ) AS authors
  FROM books b
  JOIN categories c ON c.id = b.category_id
  LEFT JOIN book_authors ba ON ba.book_id = b.id
  LEFT JOIN authors a ON a.id = ba.author_id`;
const BOOK_GROUP = 'GROUP BY b.id, c.id';

async function findBook(db, id) {
  const { rows } = await db.query(`${BOOK_SELECT} WHERE b.id = $1 ${BOOK_GROUP}`, [id]);
  return rows[0];
}

function parseAuthorIds(value) {
  if (value === undefined) return undefined;
  if (!Array.isArray(value)) throw new HttpError(400, 'Field author_ids harus berupa array angka');
  return [...new Set(value.map((v) => parseId(v, 'Isi author_ids')))];
}

// Mengganti seluruh penulis sebuah buku (tabel pivot book_authors).
async function setAuthors(client, bookId, authorIds) {
  await client.query('DELETE FROM book_authors WHERE book_id = $1', [bookId]);
  if (authorIds.length) {
    await client.query(
      'INSERT INTO book_authors (book_id, author_id) SELECT $1::int, UNNEST($2::int[])',
      [bookId, authorIds]
    );
  }
}

// GET /books?search=&category_id=&page=&limit=
router.get(
  '/',
  wrap(async (req, res) => {
    const q = req.query;
    const where = [];
    const params = [];

    if (q.search) {
      params.push(`%${q.search}%`);
      where.push(`b.title ILIKE $${params.length}`);
    }
    if (q.category_id) {
      params.push(parseId(q.category_id, 'category_id'));
      where.push(`b.category_id = $${params.length}`);
    }

    const page = Math.max(parseInt(q.page, 10) || 1, 1);
    const limit = Math.min(Math.max(parseInt(q.limit, 10) || 10, 1), 100);
    params.push(limit, (page - 1) * limit);

    const sql = `${BOOK_SELECT}
      ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
      ${BOOK_GROUP}
      ORDER BY b.id
      LIMIT $${params.length - 1} OFFSET $${params.length}`;
    const { rows } = await pool.query(sql, params);
    res.json({ data: rows, pagination: { page, limit } });
  })
);

// GET /books/:id
router.get(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const book = await findBook(pool, id);
    if (!book) throw new HttpError(404, 'Buku tidak ditemukan');
    res.json({ data: book });
  })
);

// POST /books
router.post(
  '/',
  wrap(async (req, res) => {
    const b = req.body || {};
    const title = reqStr(b.title, 'title', 200);
    const price = reqNum(b.price, 'price');
    const stock = b.stock === undefined ? 0 : reqInt(b.stock, 'stock');
    const categoryId = reqId(b.category_id, 'category_id');
    const description = optStr(b.description, 'description');
    const authorIds = parseAuthorIds(b.author_ids) || [];

    const book = await withTransaction(async (client) => {
      const ins = await client.query(
        `INSERT INTO books (title, description, price, stock, category_id)
         VALUES ($1, $2, $3, $4, $5) RETURNING id`,
        [title, description, price, stock, categoryId]
      );
      await setAuthors(client, ins.rows[0].id, authorIds);
      return findBook(client, ins.rows[0].id);
    });
    res.status(201).json({ message: 'Buku berhasil ditambahkan', data: book });
  })
);

// PUT /books/:id  (ganti seluruh data; author_ids opsional, jika ada akan menggantikan penulis lama)
router.put(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const b = req.body || {};
    const title = reqStr(b.title, 'title', 200);
    const price = reqNum(b.price, 'price');
    const stock = reqInt(b.stock, 'stock');
    const categoryId = reqId(b.category_id, 'category_id');
    const description = optStr(b.description, 'description');
    const authorIds = parseAuthorIds(b.author_ids);

    const book = await withTransaction(async (client) => {
      const upd = await client.query(
        `UPDATE books SET title = $1, description = $2, price = $3, stock = $4, category_id = $5
         WHERE id = $6 RETURNING id`,
        [title, description, price, stock, categoryId, id]
      );
      if (!upd.rows.length) throw new HttpError(404, 'Buku tidak ditemukan');
      if (authorIds !== undefined) await setAuthors(client, id, authorIds);
      return findBook(client, id);
    });
    res.json({ message: 'Buku berhasil diperbarui', data: book });
  })
);

// PATCH /books/:id  (ubah sebagian field)
router.patch(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const b = req.body || {};
    const sets = [];
    const params = [];
    const push = (column, value) => {
      params.push(value);
      sets.push(`${column} = $${params.length}`);
    };

    if (b.title !== undefined) push('title', reqStr(b.title, 'title', 200));
    if (b.description !== undefined) push('description', optStr(b.description, 'description'));
    if (b.price !== undefined) push('price', reqNum(b.price, 'price'));
    if (b.stock !== undefined) push('stock', reqInt(b.stock, 'stock'));
    if (b.category_id !== undefined) push('category_id', reqId(b.category_id, 'category_id'));
    const authorIds = parseAuthorIds(b.author_ids);

    if (!sets.length && authorIds === undefined) {
      throw new HttpError(400, 'Tidak ada field yang diubah');
    }

    const book = await withTransaction(async (client) => {
      const exists = await client.query('SELECT id FROM books WHERE id = $1 FOR UPDATE', [id]);
      if (!exists.rows.length) throw new HttpError(404, 'Buku tidak ditemukan');
      if (sets.length) {
        params.push(id);
        await client.query(`UPDATE books SET ${sets.join(', ')} WHERE id = $${params.length}`, params);
      }
      if (authorIds !== undefined) await setAuthors(client, id, authorIds);
      return findBook(client, id);
    });
    res.json({ message: 'Buku berhasil diperbarui', data: book });
  })
);

// DELETE /books/:id  (ditolak 409 jika buku sudah pernah dipesan)
router.delete(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const { rowCount } = await pool.query('DELETE FROM books WHERE id = $1', [id]);
    if (!rowCount) throw new HttpError(404, 'Buku tidak ditemukan');
    res.json({ message: 'Buku berhasil dihapus' });
  })
);

module.exports = router;
