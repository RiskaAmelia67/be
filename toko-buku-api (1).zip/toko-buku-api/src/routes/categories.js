const router = require('express').Router();
const pool = require('../db');
const { wrap, HttpError, parseId, reqStr, optStr } = require('../utils');

// GET /categories
router.get(
  '/',
  wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM categories ORDER BY id');
    res.json({ data: rows });
  })
);

// GET /categories/:id
router.get(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const { rows } = await pool.query('SELECT * FROM categories WHERE id = $1', [id]);
    if (!rows.length) throw new HttpError(404, 'Kategori tidak ditemukan');
    res.json({ data: rows[0] });
  })
);

// POST /categories
router.post(
  '/',
  wrap(async (req, res) => {
    const b = req.body || {};
    const name = reqStr(b.name, 'name', 100);
    const description = optStr(b.description, 'description');
    const { rows } = await pool.query(
      'INSERT INTO categories (name, description) VALUES ($1, $2) RETURNING *',
      [name, description]
    );
    res.status(201).json({ message: 'Kategori berhasil ditambahkan', data: rows[0] });
  })
);

// PUT /categories/:id
router.put(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const b = req.body || {};
    const name = reqStr(b.name, 'name', 100);
    const description = optStr(b.description, 'description');
    const { rows } = await pool.query(
      'UPDATE categories SET name = $1, description = $2 WHERE id = $3 RETURNING *',
      [name, description, id]
    );
    if (!rows.length) throw new HttpError(404, 'Kategori tidak ditemukan');
    res.json({ message: 'Kategori berhasil diperbarui', data: rows[0] });
  })
);

// DELETE /categories/:id
router.delete(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const { rowCount } = await pool.query('DELETE FROM categories WHERE id = $1', [id]);
    if (!rowCount) throw new HttpError(404, 'Kategori tidak ditemukan');
    res.json({ message: 'Kategori berhasil dihapus' });
  })
);

module.exports = router;
