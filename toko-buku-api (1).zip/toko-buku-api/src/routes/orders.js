const router = require('express').Router();
const pool = require('../db');
const { withTransaction } = pool;
const { wrap, HttpError, parseId, reqId, reqInt } = require('../utils');

const STATUSES = ['pending', 'paid', 'shipped', 'completed', 'cancelled'];

// Order lengkap beserta item-itemnya.
async function findOrder(db, id) {
  const o = await db.query(
    `SELECT o.id, o.user_id, u.name AS user_name, o.status, o.total_price, o.created_at
     FROM orders o JOIN users u ON u.id = o.user_id
     WHERE o.id = $1`,
    [id]
  );
  if (!o.rows.length) return null;
  const items = await db.query(
    `SELECT oi.book_id, b.title, oi.quantity, oi.unit_price,
            oi.quantity * oi.unit_price AS subtotal
     FROM order_items oi JOIN books b ON b.id = oi.book_id
     WHERE oi.order_id = $1
     ORDER BY oi.id`,
    [id]
  );
  return { ...o.rows[0], items: items.rows };
}

// Mengembalikan stok buku dari semua item sebuah order.
async function restock(client, orderId) {
  await client.query(
    `UPDATE books b SET stock = b.stock + oi.quantity
     FROM order_items oi
     WHERE oi.book_id = b.id AND oi.order_id = $1`,
    [orderId]
  );
}

// GET /orders?user_id=&status=
router.get(
  '/',
  wrap(async (req, res) => {
    const where = [];
    const params = [];
    if (req.query.user_id) {
      params.push(parseId(req.query.user_id, 'user_id'));
      where.push(`o.user_id = $${params.length}`);
    }
    if (req.query.status) {
      if (!STATUSES.includes(req.query.status)) {
        throw new HttpError(400, `Status harus salah satu dari: ${STATUSES.join(', ')}`);
      }
      params.push(req.query.status);
      where.push(`o.status = $${params.length}`);
    }
    const { rows } = await pool.query(
      `SELECT o.id, o.user_id, u.name AS user_name, o.status, o.total_price, o.created_at
       FROM orders o JOIN users u ON u.id = o.user_id
       ${where.length ? 'WHERE ' + where.join(' AND ') : ''}
       ORDER BY o.id DESC`,
      params
    );
    res.json({ data: rows });
  })
);

// GET /orders/:id
router.get(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const order = await findOrder(pool, id);
    if (!order) throw new HttpError(404, 'Order tidak ditemukan');
    res.json({ data: order });
  })
);

// POST /orders  { user_id, items: [{ book_id, quantity }] }
router.post(
  '/',
  wrap(async (req, res) => {
    const b = req.body || {};
    const userId = reqId(b.user_id, 'user_id');
    if (!Array.isArray(b.items) || !b.items.length) {
      throw new HttpError(400, 'Field items wajib berupa array dan tidak boleh kosong');
    }

    // Gabungkan item dengan book_id yang sama.
    const wanted = new Map();
    for (const item of b.items) {
      const bookId = reqId(item && item.book_id, 'items[].book_id');
      const qty = reqInt(item && item.quantity, 'items[].quantity', 1);
      wanted.set(bookId, (wanted.get(bookId) || 0) + qty);
    }

    const orderId = await withTransaction(async (client) => {
      const user = await client.query('SELECT id FROM users WHERE id = $1', [userId]);
      if (!user.rows.length) throw new HttpError(404, 'User tidak ditemukan');

      const ids = [...wanted.keys()];
      const { rows: books } = await client.query(
        'SELECT id, title, price, stock FROM books WHERE id = ANY($1::int[]) ORDER BY id FOR UPDATE',
        [ids]
      );
      if (books.length !== ids.length) {
        const found = new Set(books.map((x) => x.id));
        const missing = ids.filter((i) => !found.has(i));
        throw new HttpError(404, `Buku dengan id ${missing.join(', ')} tidak ditemukan`);
      }

      let total = 0;
      for (const book of books) {
        const qty = wanted.get(book.id);
        if (book.stock < qty) {
          throw new HttpError(400, `Stok buku "${book.title}" tidak cukup (tersisa ${book.stock})`);
        }
        total += book.price * qty;
      }
      total = Math.round(total * 100) / 100;

      const ord = await client.query(
        'INSERT INTO orders (user_id, total_price) VALUES ($1, $2) RETURNING id',
        [userId, total]
      );
      for (const book of books) {
        const qty = wanted.get(book.id);
        await client.query(
          'INSERT INTO order_items (order_id, book_id, quantity, unit_price) VALUES ($1, $2, $3, $4)',
          [ord.rows[0].id, book.id, qty, book.price]
        );
        await client.query('UPDATE books SET stock = stock - $1 WHERE id = $2', [qty, book.id]);
      }
      return ord.rows[0].id;
    });

    const order = await findOrder(pool, orderId);
    res.status(201).json({ message: 'Order berhasil dibuat', data: order });
  })
);

// PATCH /orders/:id/status  { status }
router.patch(
  '/:id/status',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const status = (req.body || {}).status;
    if (!STATUSES.includes(status)) {
      throw new HttpError(400, `Status harus salah satu dari: ${STATUSES.join(', ')}`);
    }

    await withTransaction(async (client) => {
      const cur = await client.query('SELECT status FROM orders WHERE id = $1 FOR UPDATE', [id]);
      if (!cur.rows.length) throw new HttpError(404, 'Order tidak ditemukan');
      if (cur.rows[0].status === 'cancelled') {
        throw new HttpError(400, 'Order yang sudah dibatalkan tidak dapat diubah');
      }
      if (status === 'cancelled') await restock(client, id);
      await client.query('UPDATE orders SET status = $1 WHERE id = $2', [status, id]);
    });

    const order = await findOrder(pool, id);
    res.json({ message: 'Status order berhasil diperbarui', data: order });
  })
);

// DELETE /orders/:id  (stok dikembalikan jika order belum dibatalkan)
router.delete(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    await withTransaction(async (client) => {
      const cur = await client.query('SELECT status FROM orders WHERE id = $1 FOR UPDATE', [id]);
      if (!cur.rows.length) throw new HttpError(404, 'Order tidak ditemukan');
      if (cur.rows[0].status !== 'cancelled') await restock(client, id);
      await client.query('DELETE FROM orders WHERE id = $1', [id]);
    });
    res.json({ message: 'Order berhasil dihapus' });
  })
);

module.exports = router;
