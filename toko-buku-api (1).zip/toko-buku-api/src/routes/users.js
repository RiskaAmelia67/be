const router = require('express').Router();
const pool = require('../db');
const { wrap, HttpError, parseId, reqStr, optStr, reqEmail } = require('../utils');

// GET /users
router.get(
  '/',
  wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM users ORDER BY id');
    res.json({ data: rows });
  })
);

// GET /users/:id
router.get(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const { rows } = await pool.query('SELECT * FROM users WHERE id = $1', [id]);
    if (!rows.length) throw new HttpError(404, 'User tidak ditemukan');
    res.json({ data: rows[0] });
  })
);

// POST /users
router.post(
  '/',
  wrap(async (req, res) => {
    const b = req.body || {};
    const name = reqStr(b.name, 'name', 100);
    const email = reqEmail(b.email);
    const phone = optStr(b.phone, 'phone', 20);
    const { rows } = await pool.query(
      'INSERT INTO users (name, email, phone) VALUES ($1, $2, $3) RETURNING *',
      [name, email, phone]
    );
    res.status(201).json({ message: 'User berhasil ditambahkan', data: rows[0] });
  })
);

// PUT /users/:id
router.put(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const b = req.body || {};
    const name = reqStr(b.name, 'name', 100);
    const email = reqEmail(b.email);
    const phone = optStr(b.phone, 'phone', 20);
    const { rows } = await pool.query(
      'UPDATE users SET name = $1, email = $2, phone = $3 WHERE id = $4 RETURNING *',
      [name, email, phone, id]
    );
    if (!rows.length) throw new HttpError(404, 'User tidak ditemukan');
    res.json({ message: 'User berhasil diperbarui', data: rows[0] });
  })
);

// DELETE /users/:id  (ditolak 409 jika user masih punya order)
router.delete(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const { rowCount } = await pool.query('DELETE FROM users WHERE id = $1', [id]);
    if (!rowCount) throw new HttpError(404, 'User tidak ditemukan');
    res.json({ message: 'User berhasil dihapus' });
  })
);

module.exports = router;
