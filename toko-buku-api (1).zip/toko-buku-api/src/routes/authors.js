const router = require('express').Router();
const pool = require('../db');
const { wrap, HttpError, parseId, reqStr, optStr } = require('../utils');

// GET /authors
router.get(
  '/',
  wrap(async (req, res) => {
    const { rows } = await pool.query('SELECT * FROM authors ORDER BY id');
    res.json({ data: rows });
  })
);

// GET /authors/:id
router.get(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const { rows } = await pool.query('SELECT * FROM authors WHERE id = $1', [id]);
    if (!rows.length) throw new HttpError(404, 'Penulis tidak ditemukan');
    res.json({ data: rows[0] });
  })
);

// POST /authors
router.post(
  '/',
  wrap(async (req, res) => {
    const b = req.body || {};
    const name = reqStr(b.name, 'name', 100);
    const bio = optStr(b.bio, 'bio');
    const { rows } = await pool.query(
      'INSERT INTO authors (name, bio) VALUES ($1, $2) RETURNING *',
      [name, bio]
    );
    res.status(201).json({ message: 'Penulis berhasil ditambahkan', data: rows[0] });
  })
);

// PUT /authors/:id
router.put(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const b = req.body || {};
    const name = reqStr(b.name, 'name', 100);
    const bio = optStr(b.bio, 'bio');
    const { rows } = await pool.query(
      'UPDATE authors SET name = $1, bio = $2 WHERE id = $3 RETURNING *',
      [name, bio, id]
    );
    if (!rows.length) throw new HttpError(404, 'Penulis tidak ditemukan');
    res.json({ message: 'Penulis berhasil diperbarui', data: rows[0] });
  })
);

// DELETE /authors/:id  (relasi di book_authors ikut terhapus)
router.delete(
  '/:id',
  wrap(async (req, res) => {
    const id = parseId(req.params.id);
    const { rowCount } = await pool.query('DELETE FROM authors WHERE id = $1', [id]);
    if (!rowCount) throw new HttpError(404, 'Penulis tidak ditemukan');
    res.json({ message: 'Penulis berhasil dihapus' });
  })
);

module.exports = router;
