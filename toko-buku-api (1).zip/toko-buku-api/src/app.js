require('dotenv').config();
const express = require('express');
const { notFound, errorHandler } = require('./utils');

const app = express();
app.use(express.json());

app.get('/', (req, res) => {
  res.json({
    message: 'Toko Buku REST API',
    endpoints: ['/categories', '/authors', '/users', '/books', '/orders'],
  });
});

app.use('/categories', require('./routes/categories'));
app.use('/authors', require('./routes/authors'));
app.use('/users', require('./routes/users'));
app.use('/books', require('./routes/books'));
app.use('/orders', require('./routes/orders'));

app.use(notFound);
app.use(errorHandler);

module.exports = app;
