const { Pool, types } = require('pg');

// Kolom NUMERIC dari Postgres dikirim sebagai string; ubah jadi angka agar JSON-nya rapi.
types.setTypeParser(1700, (value) => parseFloat(value));

if (!process.env.DATABASE_URL) {
  console.warn('PERINGATAN: DATABASE_URL belum diisi (lihat .env.example).');
}

// Neon/Supabase mewajibkan SSL. Set DB_SSL=false untuk Postgres lokal.
const ssl = process.env.DB_SSL === 'false' ? false : { rejectUnauthorized: false };

const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl,
  max: 3, // kecil, karena serverless membuka banyak instance
});

// Menjalankan beberapa query dalam satu transaksi (semua berhasil atau dibatalkan semua).
async function withTransaction(fn) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await fn(client);
    await client.query('COMMIT');
    return result;
  } catch (err) {
    try {
      await client.query('ROLLBACK');
    } catch (_) {
      /* abaikan error rollback */
    }
    throw err;
  } finally {
    client.release();
  }
}

module.exports = pool;
module.exports.withTransaction = withTransaction;
