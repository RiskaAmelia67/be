// Entry point untuk Vercel (Serverless Function).
// Semua request diarahkan ke sini oleh vercel.json, lalu ditangani oleh Express.
module.exports = require('../src/app');
