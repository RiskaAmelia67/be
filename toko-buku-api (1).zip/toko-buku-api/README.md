# Toko Buku REST API

REST API sederhana untuk toko buku online, dibuat untuk **Tugas Akhir Learning Labs: Backend Development**.
API mengelola kategori, penulis, buku, user, dan order (pemesanan) beserta item-itemnya.

- **Stack**: Node.js, Express, PostgreSQL (Neon), deploy di Vercel
- **Format**: JSON untuk semua request dan response
- **Link repository**: `https://github.com/USERNAME/toko-buku-api`  *(ganti dengan link repository kamu)*
- **Link deployment**: `https://NAMA-PROJECT.vercel.app`  *(ganti dengan URL Vercel kamu)*

---

## 1. Skema Database (ERD)

Terdapat **7 tabel** dengan relasi foreign key:

| Tabel | Keterangan | Relasi |
|-------|------------|--------|
| `users` | Pelanggan | satu user punya banyak `orders` (one-to-many) |
| `categories` | Kategori buku | satu kategori punya banyak `books` (one-to-many) |
| `authors` | Penulis | many-to-many dengan `books` lewat `book_authors` |
| `books` | Buku | `category_id` -> `categories.id` |
| `book_authors` | Tabel pivot buku-penulis | `book_id` -> `books.id`, `author_id` -> `authors.id` (many-to-many) |
| `orders` | Pesanan | `user_id` -> `users.id` |
| `order_items` | Item dalam pesanan | `order_id` -> `orders.id`, `book_id` -> `books.id` |

```mermaid
erDiagram
    users ||--o{ orders : "membuat"
    orders ||--|{ order_items : "berisi"
    books ||--o{ order_items : "dipesan di"
    categories ||--o{ books : "mengelompokkan"
    books ||--o{ book_authors : "ditulis oleh"
    authors ||--o{ book_authors : "menulis"

    users {
        int id PK
        varchar name
        varchar email UK
        varchar phone
        timestamptz created_at
    }
    categories {
        int id PK
        varchar name UK
        text description
    }
    authors {
        int id PK
        varchar name
        text bio
    }
    books {
        int id PK
        varchar title
        text description
        numeric price
        int stock
        int category_id FK
        timestamptz created_at
    }
    book_authors {
        int book_id PK, FK
        int author_id PK, FK
    }
    orders {
        int id PK
        int user_id FK
        varchar status
        numeric total_price
        timestamptz created_at
    }
    order_items {
        int id PK
        int order_id FK
        int book_id FK
        int quantity
        numeric unit_price
    }
```

Gambar ERD (PNG) ada di `docs/erd.png`, dibuat dari `docs/erd.dbml` menggunakan [dbdiagram.io](https://dbdiagram.io).
SQL pembuatan tabel ada di `db/schema.sql`.

---

## 2. Cara Menjalankan Secara Lokal

Prasyarat: Node.js 18+ dan sebuah database PostgreSQL yang bisa diakses (disarankan [Neon](https://neon.tech) atau Supabase).

```bash
# 1. Clone dan install dependency
git clone https://github.com/USERNAME/toko-buku-api.git
cd toko-buku-api
npm install

# 2. Buat file .env dari contoh, lalu isi DATABASE_URL
cp .env.example .env

# 3. Buat tabel dan isi data contoh
npm run db:init

# 4. Jalankan server
npm start          # atau: npm run dev (auto-reload)
```

Server berjalan di `http://localhost:3000`. Jika memakai Postgres lokal tanpa SSL, tambahkan `DB_SSL=false` di `.env`.

> `npm run db:init` memasukkan data contoh (`db/seed.sql`) dan sebaiknya hanya dijalankan **sekali** pada database kosong.
> Gunakan `npm run db:schema` jika hanya ingin membuat tabel tanpa data contoh.

## 3. Deployment ke Vercel

1. Push project ke GitHub (pastikan `.env` tidak ikut ter-commit; sudah masuk `.gitignore`).
2. Di [vercel.com](https://vercel.com), pilih **Add New > Project**, lalu import repository ini.
3. Pada **Settings > Environment Variables**, tambahkan `DATABASE_URL` berisi connection string database Neon/Supabase.
4. Klik **Deploy**. Konfigurasi routing ada di `vercel.json` (semua request diarahkan ke `api/index.js`).
5. Jalankan `npm run db:init` sekali dari laptop (dengan `DATABASE_URL` yang sama) untuk membuat tabel di database online.

## 4. Pengujian

- Import file `postman_collection.json` ke Postman atau Thunder Client.
- Ubah variabel koleksi `baseUrl` menjadi URL Vercel kamu (bukan `localhost`).
- Jalankan request **berurutan dari atas ke bawah** (folder Categories sampai Orders). Request POST menyimpan id data baru ke variabel koleksi, sehingga request GET/PUT/PATCH/DELETE sesudahnya otomatis memakai id tersebut.
- Simpan screenshot request dan response setiap endpoint sebagai bukti pengujian di folder `docs/bukti-pengujian/`.

## 5. Aturan Umum API

- Semua body request dan response berformat JSON. Kirim header `Content-Type: application/json` untuk request yang memakai body.
- Response sukses berisi `data` dan/atau `message`. Response error selalu berbentuk `{ "error": "pesan" }`.

| Status | Arti |
|--------|------|
| `200 OK` | Berhasil mengambil, mengubah, atau menghapus data |
| `201 Created` | Data baru berhasil dibuat |
| `400 Bad Request` | Input tidak valid atau field wajib kosong |
| `404 Not Found` | Data atau endpoint tidak ditemukan |
| `409 Conflict` | Data duplikat, atau data tidak bisa dihapus karena masih dipakai data lain |
| `500 Internal Server Error` | Kesalahan pada server |

---

## 6. Daftar Endpoint

Ringkasan (total 26 endpoint):

| No | Method | Endpoint | Deskripsi |
|----|--------|----------|-----------|
| 1 | GET | `/categories` | Mengambil semua kategori |
| 2 | POST | `/categories` | Menambahkan kategori baru |
| 3 | GET | `/categories/4` | Mengambil satu kategori berdasarkan id |
| 4 | PUT | `/categories/4` | Mengubah seluruh data kategori |
| 5 | DELETE | `/categories/4` | Menghapus kategori |
| 6 | GET | `/authors` | Mengambil semua penulis |
| 7 | POST | `/authors` | Menambahkan penulis baru |
| 8 | GET | `/authors/4` | Mengambil satu penulis berdasarkan id |
| 9 | PUT | `/authors/4` | Mengubah seluruh data penulis |
| 10 | DELETE | `/authors/4` | Menghapus penulis (relasinya di book_authors ikut terhapus) |
| 11 | GET | `/users` | Mengambil semua user |
| 12 | POST | `/users` | Mendaftarkan user baru |
| 13 | GET | `/users/3` | Mengambil satu user berdasarkan id |
| 14 | PUT | `/users/3` | Mengubah seluruh data user |
| 15 | DELETE | `/users/3` | Menghapus user |
| 16 | GET | `/books` | Mengambil daftar buku beserta kategori dan penulisnya |
| 17 | POST | `/books` | Menambahkan buku baru |
| 18 | GET | `/books/5` | Mengambil satu buku berdasarkan id |
| 19 | PUT | `/books/5` | Mengganti seluruh data buku |
| 20 | PATCH | `/books/5` | Mengubah sebagian field buku (kirim hanya field yang ingin diubah) |
| 21 | DELETE | `/books/5` | Menghapus buku |
| 22 | GET | `/orders` | Mengambil daftar order |
| 23 | POST | `/orders` | Membuat order |
| 24 | GET | `/orders/1` | Mengambil satu order lengkap dengan item-itemnya |
| 25 | PATCH | `/orders/1/status` | Mengubah status order |
| 26 | DELETE | `/orders/1` | Menghapus order (stok dikembalikan jika order belum dibatalkan) |

## Categories

### 1. Daftar Kategori
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/categories
- Deskripsi    : Mengambil semua kategori
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": [
      {
        "id": 1,
        "name": "Pemrograman",
        "description": "Buku seputar pemrograman dan teknologi"
      }
    ]
  }
- Response Error (500):
  {
    "error": "Terjadi kesalahan pada server"
  }
```

### 2. Tambah Kategori
```text
- Method       : POST
- URL          : https://NAMA-PROJECT.vercel.app/categories
- Deskripsi    : Menambahkan kategori baru
- Headers      : Content-Type: application/json
- Request Body :
  {
    "name": "Fiksi Sejarah",
    "description": "Novel berlatar sejarah"
  }
- Response Sukses (201):
  {
    "message": "Kategori berhasil ditambahkan",
    "data": {
      "id": 4,
      "name": "Fiksi Sejarah",
      "description": "Novel berlatar sejarah"
    }
  }
- Response Error (400):
  {
    "error": "Field name wajib diisi"
  }
```

### 3. Detail Kategori
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/categories/4
- Deskripsi    : Mengambil satu kategori berdasarkan id
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": {
      "id": 4,
      "name": "Fiksi Sejarah",
      "description": "Novel berlatar sejarah"
    }
  }
- Response Error (404):
  {
    "error": "Kategori tidak ditemukan"
  }
```

### 4. Ubah Kategori
```text
- Method       : PUT
- URL          : https://NAMA-PROJECT.vercel.app/categories/4
- Deskripsi    : Mengubah seluruh data kategori
- Headers      : Content-Type: application/json
- Request Body :
  {
    "name": "Fiksi Sejarah Indonesia",
    "description": "Novel sejarah Nusantara"
  }
- Response Sukses (200):
  {
    "message": "Kategori berhasil diperbarui",
    "data": {
      "id": 4,
      "name": "Fiksi Sejarah Indonesia",
      "description": "Novel sejarah Nusantara"
    }
  }
- Response Error (404):
  {
    "error": "Kategori tidak ditemukan"
  }
```

### 5. Hapus Kategori
```text
- Method       : DELETE
- URL          : https://NAMA-PROJECT.vercel.app/categories/4
- Deskripsi    : Menghapus kategori. Ditolak jika masih dipakai oleh buku
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "message": "Kategori berhasil dihapus"
  }
- Response Error (409):
  {
    "error": "Data tidak dapat dihapus karena masih dipakai oleh data lain"
  }
```

## Authors

### 6. Daftar Penulis
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/authors
- Deskripsi    : Mengambil semua penulis
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": [
      {
        "id": 1,
        "name": "Budi Santoso",
        "bio": "Software engineer dan penulis buku teknologi"
      }
    ]
  }
- Response Error (500):
  {
    "error": "Terjadi kesalahan pada server"
  }
```

### 7. Tambah Penulis
```text
- Method       : POST
- URL          : https://NAMA-PROJECT.vercel.app/authors
- Deskripsi    : Menambahkan penulis baru
- Headers      : Content-Type: application/json
- Request Body :
  {
    "name": "Agus Salim",
    "bio": "Penulis buku sejarah"
  }
- Response Sukses (201):
  {
    "message": "Penulis berhasil ditambahkan",
    "data": {
      "id": 4,
      "name": "Agus Salim",
      "bio": "Penulis buku sejarah"
    }
  }
- Response Error (400):
  {
    "error": "Field name wajib diisi"
  }
```

### 8. Detail Penulis
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/authors/4
- Deskripsi    : Mengambil satu penulis berdasarkan id
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": {
      "id": 4,
      "name": "Agus Salim",
      "bio": "Penulis buku sejarah"
    }
  }
- Response Error (404):
  {
    "error": "Penulis tidak ditemukan"
  }
```

### 9. Ubah Penulis
```text
- Method       : PUT
- URL          : https://NAMA-PROJECT.vercel.app/authors/4
- Deskripsi    : Mengubah seluruh data penulis
- Headers      : Content-Type: application/json
- Request Body :
  {
    "name": "Agus Salim",
    "bio": "Sejarawan dan penulis"
  }
- Response Sukses (200):
  {
    "message": "Penulis berhasil diperbarui",
    "data": {
      "id": 4,
      "name": "Agus Salim",
      "bio": "Sejarawan dan penulis"
    }
  }
- Response Error (404):
  {
    "error": "Penulis tidak ditemukan"
  }
```

### 10. Hapus Penulis
```text
- Method       : DELETE
- URL          : https://NAMA-PROJECT.vercel.app/authors/4
- Deskripsi    : Menghapus penulis (relasinya di book_authors ikut terhapus)
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "message": "Penulis berhasil dihapus"
  }
- Response Error (404):
  {
    "error": "Penulis tidak ditemukan"
  }
```

## Users

### 11. Daftar User
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/users
- Deskripsi    : Mengambil semua user
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": [
      {
        "id": 1,
        "name": "Siti Aminah",
        "email": "siti@example.com",
        "phone": "081234567890",
        "created_at": "2026-10-26T04:30:00.000Z"
      }
    ]
  }
- Response Error (500):
  {
    "error": "Terjadi kesalahan pada server"
  }
```

### 12. Tambah User
```text
- Method       : POST
- URL          : https://NAMA-PROJECT.vercel.app/users
- Deskripsi    : Mendaftarkan user baru. Email harus unik (duplikat -> 409)
- Headers      : Content-Type: application/json
- Request Body :
  {
    "name": "Budi Hartono",
    "email": "budi@example.com",
    "phone": "081355577799"
  }
- Response Sukses (201):
  {
    "message": "User berhasil ditambahkan",
    "data": {
      "id": 3,
      "name": "Budi Hartono",
      "email": "budi@example.com",
      "phone": "081355577799",
      "created_at": "2026-10-26T04:30:00.000Z"
    }
  }
- Response Error (400):
  {
    "error": "Format email tidak valid"
  }
```

### 13. Detail User
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/users/3
- Deskripsi    : Mengambil satu user berdasarkan id
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": {
      "id": 3,
      "name": "Budi Hartono",
      "email": "budi@example.com",
      "phone": "081355577799",
      "created_at": "2026-10-26T04:30:00.000Z"
    }
  }
- Response Error (404):
  {
    "error": "User tidak ditemukan"
  }
```

### 14. Ubah User
```text
- Method       : PUT
- URL          : https://NAMA-PROJECT.vercel.app/users/3
- Deskripsi    : Mengubah seluruh data user
- Headers      : Content-Type: application/json
- Request Body :
  {
    "name": "Budi Hartono",
    "email": "budi.h@example.com",
    "phone": "081355577799"
  }
- Response Sukses (200):
  {
    "message": "User berhasil diperbarui",
    "data": {
      "id": 3,
      "name": "Budi Hartono",
      "email": "budi.h@example.com",
      "phone": "081355577799",
      "created_at": "2026-10-26T04:30:00.000Z"
    }
  }
- Response Error (404):
  {
    "error": "User tidak ditemukan"
  }
```

### 15. Hapus User
```text
- Method       : DELETE
- URL          : https://NAMA-PROJECT.vercel.app/users/3
- Deskripsi    : Menghapus user. Ditolak jika user masih punya order
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "message": "User berhasil dihapus"
  }
- Response Error (404):
  {
    "error": "User tidak ditemukan"
  }
```

## Books

### 16. Daftar Buku
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/books?search=python&category_id=1&page=1&limit=10
- Deskripsi    : Mengambil daftar buku beserta kategori dan penulisnya. Query opsional: search (judul), category_id, page, limit (maks. 100)
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": [
      {
        "id": 1,
        "title": "Belajar Python",
        "description": "Panduan Python untuk pemula",
        "price": 85000,
        "stock": 20,
        "category_id": 1,
        "category": "Pemrograman",
        "authors": [
          {
            "id": 1,
            "name": "Budi Santoso"
          }
        ]
      }
    ],
    "pagination": {
      "page": 1,
      "limit": 10
    }
  }
- Response Error (400):
  {
    "error": "category_id harus berupa angka bulat positif"
  }
```

### 17. Tambah Buku
```text
- Method       : POST
- URL          : https://NAMA-PROJECT.vercel.app/books
- Deskripsi    : Menambahkan buku baru. author_ids (opsional) mengisi tabel pivot book_authors
- Headers      : Content-Type: application/json
- Request Body :
  {
    "title": "Belajar Node.js",
    "description": "Dasar Node.js untuk backend",
    "price": 90000,
    "stock": 25,
    "category_id": 1,
    "author_ids": [
      1
    ]
  }
- Response Sukses (201):
  {
    "message": "Buku berhasil ditambahkan",
    "data": {
      "id": 5,
      "title": "Belajar Node.js",
      "description": "Dasar Node.js untuk backend",
      "price": 90000,
      "stock": 25,
      "category_id": 1,
      "category": "Pemrograman",
      "authors": [
        {
          "id": 1,
          "name": "Budi Santoso"
        }
      ]
    }
  }
- Response Error (400):
  {
    "error": "Field title wajib diisi"
  }
```

### 18. Detail Buku
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/books/5
- Deskripsi    : Mengambil satu buku berdasarkan id
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": {
      "id": 5,
      "title": "Belajar Node.js",
      "description": "Dasar Node.js untuk backend",
      "price": 90000,
      "stock": 25,
      "category_id": 1,
      "category": "Pemrograman",
      "authors": [
        {
          "id": 1,
          "name": "Budi Santoso"
        }
      ]
    }
  }
- Response Error (404):
  {
    "error": "Buku tidak ditemukan"
  }
```

### 19. Ubah Buku (PUT)
```text
- Method       : PUT
- URL          : https://NAMA-PROJECT.vercel.app/books/5
- Deskripsi    : Mengganti seluruh data buku. Wajib: title, price, stock, category_id
- Headers      : Content-Type: application/json
- Request Body :
  {
    "title": "Belajar Node.js Lengkap",
    "description": "Edisi revisi",
    "price": 99000,
    "stock": 30,
    "category_id": 1,
    "author_ids": [
      1,
      3
    ]
  }
- Response Sukses (200):
  {
    "message": "Buku berhasil diperbarui",
    "data": {
      "id": 5,
      "title": "Belajar Node.js Lengkap",
      "description": "Edisi revisi",
      "price": 99000,
      "stock": 30,
      "category_id": 1,
      "category": "Pemrograman",
      "authors": [
        {
          "id": 1,
          "name": "Budi Santoso"
        },
        {
          "id": 3,
          "name": "Dewi Lestari"
        }
      ]
    }
  }
- Response Error (400):
  {
    "error": "Field price harus berupa angka >= 0"
  }
```

### 20. Ubah Sebagian Buku (PATCH)
```text
- Method       : PATCH
- URL          : https://NAMA-PROJECT.vercel.app/books/5
- Deskripsi    : Mengubah sebagian field buku (kirim hanya field yang ingin diubah)
- Headers      : Content-Type: application/json
- Request Body :
  {
    "price": 95000,
    "stock": 40
  }
- Response Sukses (200):
  {
    "message": "Buku berhasil diperbarui",
    "data": {
      "id": 5,
      "title": "Belajar Node.js Lengkap",
      "description": "Dasar Node.js untuk backend",
      "price": 95000,
      "stock": 40,
      "category_id": 1,
      "category": "Pemrograman",
      "authors": [
        {
          "id": 1,
          "name": "Budi Santoso"
        }
      ]
    }
  }
- Response Error (400):
  {
    "error": "Tidak ada field yang diubah"
  }
```

### 21. Hapus Buku
```text
- Method       : DELETE
- URL          : https://NAMA-PROJECT.vercel.app/books/5
- Deskripsi    : Menghapus buku. Ditolak (409) jika buku sudah pernah dipesan
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "message": "Buku berhasil dihapus"
  }
- Response Error (404):
  {
    "error": "Buku tidak ditemukan"
  }
```

## Orders

### 22. Daftar Order
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/orders?user_id=1&status=pending
- Deskripsi    : Mengambil daftar order. Query opsional: user_id, status (pending|paid|shipped|completed|cancelled)
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": [
      {
        "id": 1,
        "user_id": 1,
        "user_name": "Siti Aminah",
        "status": "pending",
        "total_price": 170000,
        "created_at": "2026-10-26T04:30:00.000Z"
      }
    ]
  }
- Response Error (400):
  {
    "error": "Status harus salah satu dari: pending, paid, shipped, completed, cancelled"
  }
```

### 23. Buat Order
```text
- Method       : POST
- URL          : https://NAMA-PROJECT.vercel.app/orders
- Deskripsi    : Membuat order. Total dihitung otomatis dari harga buku, stok berkurang otomatis (dalam satu transaksi database)
- Headers      : Content-Type: application/json
- Request Body :
  {
    "user_id": 1,
    "items": [
      {
        "book_id": 1,
        "quantity": 2
      }
    ]
  }
- Response Sukses (201):
  {
    "message": "Order berhasil dibuat",
    "data": {
      "id": 1,
      "user_id": 1,
      "user_name": "Siti Aminah",
      "status": "pending",
      "total_price": 170000,
      "created_at": "2026-10-26T04:30:00.000Z",
      "items": [
        {
          "book_id": 1,
          "title": "Belajar Python",
          "quantity": 2,
          "unit_price": 85000,
          "subtotal": 170000
        }
      ]
    }
  }
- Response Error (400):
  {
    "error": "Field items wajib berupa array dan tidak boleh kosong"
  }
```

### 24. Detail Order
```text
- Method       : GET
- URL          : https://NAMA-PROJECT.vercel.app/orders/1
- Deskripsi    : Mengambil satu order lengkap dengan item-itemnya
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "data": {
      "id": 1,
      "user_id": 1,
      "user_name": "Siti Aminah",
      "status": "pending",
      "total_price": 170000,
      "created_at": "2026-10-26T04:30:00.000Z",
      "items": [
        {
          "book_id": 1,
          "title": "Belajar Python",
          "quantity": 2,
          "unit_price": 85000,
          "subtotal": 170000
        }
      ]
    }
  }
- Response Error (404):
  {
    "error": "Order tidak ditemukan"
  }
```

### 25. Ubah Status Order
```text
- Method       : PATCH
- URL          : https://NAMA-PROJECT.vercel.app/orders/1/status
- Deskripsi    : Mengubah status order. Status "cancelled" mengembalikan stok dan tidak bisa diubah lagi
- Headers      : Content-Type: application/json
- Request Body :
  {
    "status": "paid"
  }
- Response Sukses (200):
  {
    "message": "Status order berhasil diperbarui",
    "data": {
      "id": 1,
      "user_id": 1,
      "user_name": "Siti Aminah",
      "status": "paid",
      "total_price": 170000,
      "created_at": "2026-10-26T04:30:00.000Z",
      "items": [
        {
          "book_id": 1,
          "title": "Belajar Python",
          "quantity": 2,
          "unit_price": 85000,
          "subtotal": 170000
        }
      ]
    }
  }
- Response Error (400):
  {
    "error": "Status harus salah satu dari: pending, paid, shipped, completed, cancelled"
  }
```

### 26. Hapus Order
```text
- Method       : DELETE
- URL          : https://NAMA-PROJECT.vercel.app/orders/1
- Deskripsi    : Menghapus order (stok dikembalikan jika order belum dibatalkan)
- Headers      : -
- Request Body : -
- Response Sukses (200):
  {
    "message": "Order berhasil dihapus"
  }
- Response Error (404):
  {
    "error": "Order tidak ditemukan"
  }
```


---

## Struktur Project

```
toko-buku-api/
├── api/index.js           # entry point Vercel
├── server.js              # entry point lokal
├── vercel.json            # konfigurasi routing Vercel
├── db/
│   ├── schema.sql         # pembuatan tabel
│   └── seed.sql           # data contoh
├── scripts/init-db.js     # menjalankan schema + seed
├── src/
│   ├── app.js             # setup Express
│   ├── db.js              # koneksi PostgreSQL + transaksi
│   ├── utils.js           # validasi input + error handler
│   └── routes/            # categories, authors, users, books, orders
├── docs/
│   ├── erd.dbml           # sumber ERD untuk dbdiagram.io
│   └── erd.png            # gambar ERD
└── postman_collection.json
```
