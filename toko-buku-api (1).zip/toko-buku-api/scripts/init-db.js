// Membuat tabel (db/schema.sql) dan mengisi data contoh (db/seed.sql).
// Pakai: npm run db:init           -> schema + seed
//        npm run db:schema         -> schema saja
require('dotenv').config();
const fs = require('fs');
const path = require('path');
const pool = require('../src/db');

async function run() {
  const withSeed = !process.argv.includes('--no-seed');
  const files = ['schema.sql'];
  if (withSeed) files.push('seed.sql');

  for (const file of files) {
    const sql = fs.readFileSync(path.join(__dirname, '..', 'db', file), 'utf8');
    await pool.query(sql);
    console.log(`OK: ${file} dijalankan`);
  }
}

run()
  .catch((err) => {
    console.error('Gagal menjalankan SQL:', err.message);
    process.exitCode = 1;
  })
  .finally(() => pool.end());
