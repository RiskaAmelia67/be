-- Data contoh. Jalankan sekali pada database yang masih kosong.

INSERT INTO users (name, email, phone) VALUES
  ('Siti Aminah', 'siti@example.com', '081234567890'),
  ('Andi Wijaya', 'andi@example.com', '081298765432');

INSERT INTO categories (name, description) VALUES
  ('Pemrograman', 'Buku seputar pemrograman dan teknologi'),
  ('Fiksi', 'Novel dan kumpulan cerita'),
  ('Bisnis', 'Buku manajemen, keuangan, dan kewirausahaan');

INSERT INTO authors (name, bio) VALUES
  ('Budi Santoso', 'Software engineer dan penulis buku teknologi'),
  ('Rina Kartika', 'Novelis dengan beberapa buku terbitan nasional'),
  ('Dewi Lestari', 'Konsultan bisnis dan penulis');

INSERT INTO books (title, description, price, stock, category_id) VALUES
  ('Belajar Python', 'Panduan Python untuk pemula', 85000, 20, 1),
  ('REST API dengan Express', 'Membangun backend modern dengan Node.js', 95000, 15, 1),
  ('Senja di Surakarta', 'Novel tentang kota dan kenangan', 70000, 30, 2),
  ('Startup dari Nol', 'Langkah awal membangun bisnis', 110000, 10, 3);

INSERT INTO book_authors (book_id, author_id) VALUES
  (1, 1),
  (2, 1),
  (2, 3),
  (3, 2),
  (4, 3);
