-- Skema database Toko Buku (PostgreSQL)
-- 7 tabel: users, categories, authors, books, book_authors (pivot), orders, order_items

CREATE TABLE IF NOT EXISTS users (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(100) NOT NULL,
  email       VARCHAR(150) NOT NULL UNIQUE,
  phone       VARCHAR(20),
  created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS categories (
  id          SERIAL PRIMARY KEY,
  name        VARCHAR(100) NOT NULL UNIQUE,
  description TEXT
);

CREATE TABLE IF NOT EXISTS authors (
  id    SERIAL PRIMARY KEY,
  name  VARCHAR(100) NOT NULL,
  bio   TEXT
);

-- One-to-many: satu category punya banyak books
CREATE TABLE IF NOT EXISTS books (
  id           SERIAL PRIMARY KEY,
  title        VARCHAR(200) NOT NULL,
  description  TEXT,
  price        NUMERIC(12,2) NOT NULL CHECK (price >= 0),
  stock        INTEGER NOT NULL DEFAULT 0 CHECK (stock >= 0),
  category_id  INTEGER NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Many-to-many: satu buku bisa punya banyak penulis, satu penulis bisa menulis banyak buku
CREATE TABLE IF NOT EXISTS book_authors (
  book_id    INTEGER NOT NULL REFERENCES books(id)   ON DELETE CASCADE,
  author_id  INTEGER NOT NULL REFERENCES authors(id) ON DELETE CASCADE,
  PRIMARY KEY (book_id, author_id)
);

-- One-to-many: satu user punya banyak orders
CREATE TABLE IF NOT EXISTS orders (
  id           SERIAL PRIMARY KEY,
  user_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
  status       VARCHAR(20) NOT NULL DEFAULT 'pending'
               CHECK (status IN ('pending', 'paid', 'shipped', 'completed', 'cancelled')),
  total_price  NUMERIC(12,2) NOT NULL DEFAULT 0 CHECK (total_price >= 0),
  created_at   TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- One-to-many: satu order punya banyak order_items; tiap item menunjuk ke satu buku
CREATE TABLE IF NOT EXISTS order_items (
  id          SERIAL PRIMARY KEY,
  order_id    INTEGER NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
  book_id     INTEGER NOT NULL REFERENCES books(id)  ON DELETE RESTRICT,
  quantity    INTEGER NOT NULL CHECK (quantity > 0),
  unit_price  NUMERIC(12,2) NOT NULL CHECK (unit_price >= 0),
  UNIQUE (order_id, book_id)
);

CREATE INDEX IF NOT EXISTS idx_books_category   ON books(category_id);
CREATE INDEX IF NOT EXISTS idx_orders_user      ON orders(user_id);
CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
